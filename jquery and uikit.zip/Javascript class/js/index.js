$(document).ready(function(){

$("h2").siblings("h3").css({

     "color":"red",
     "border":"2px solid red",
     "text-align":"center"
     
})

});

$(document).ready(function(){

$("#chaining-btn").click(function(){
     $("#chaining-text").hide(2000,function(){
          alert("Hi Your are exactly Done")
     })
})

});

$(document).ready(function(){
$("#slide-btn").click(function(){
     $("#slide-text").css({
          
          "left":"250px",
          "color":"#fff",
        "background-color":"#000",
          "border-radius":"7px"
     })
     .slideUp(2000)
     .slideDown(2000)
     .hide(2000)
})

});

$(document).ready(function(){

$(".uk-button").click(function(){
     $(".ajax-text").load("ajax.html")
});

});